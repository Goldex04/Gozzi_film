﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Gozzi_service_film{
    public partial class Form1 : Form{
        public Form1(){
            InitializeComponent();
            Gozzi_service_film.init();
        }
        public class Film{
                public string Title { get; set; }
                public string Year { get; set; }
                public string Rated { get; set; }
                public string Released { get; set; }
                public string Runtime { get; set; }
                public string Genre { get; set; }
                public string Plot { get; set; }
                public string Director { get; set; }
                public string Writer { get; set; }
                public string Actors { get; set; }
                public string Language { get; set; }
                public string Country { get; set; }
                public string Awards { get; set; }
                public string Metascore { get; set; }
                public string imdbRating { get; set; }
                public string BoxOffice { get; set; }
                public string Poster { get; set; }
                public string ToString(){
                    return "Film: " + Title + "," 
                    + Year + "," 
                    + Rated+ "," 
                    + Released + "," 
                    + Runtime + "," 
                    + Genre + "," 
                    + Director + "," 
                    + Actors + "," 
                    + Plot + "," 
                    + Poster;
                }
        }
        public class Gozzi_service_film{
            static HttpClient client = new HttpClient();
            public static void init(){
                client.BaseAddress = new Uri("https://www.omdbapi.com");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
            }
            static void ShowProduct(Film film){
                Console.WriteLine(film.ToString());
            }
            public static async Task<Film> OttieniInformazioni(string path){
                Film richiesta = null;
                HttpResponseMessage response = await client.GetAsync(path);
                if (response.IsSuccessStatusCode){
                    richiesta = await JsonSerializer.DeserializeAsync<Film>(await response.Content.ReadAsStreamAsync());
                }
                return richiesta;
            }
        }
        private async void button1_Click(object sender, EventArgs e){
            string titolo = textBoxTitolo.Text.Replace(" ", "+");
            string trama = comboBoxTrama.Text;
            string informazioni = "/?apikey=63c6db0e&t=" + titolo+"&plot="+trama;
            Film a = new Film();
            a = await Gozzi_service_film.OttieniInformazioni(informazioni);
            if (a != null){
                    richTextBoxInformazioni.Text = "Titolo del film: " + a.Title + "\n"
                    + "Anno di uscita: " + a.Year + "\n"
                    + "Limite d'età: " + a.Rated + "\n"
                    + "Genere: " + a.Genre + "\n"
                    + "Trama del film: " + a.Plot + "\n"
                    + "Durata del film: " + a.Runtime + "\n"
                    + "Regista: " + a.Director + "\n"
                    + "Sceneggiatori: " + a.Writer + "\n"
                    + "Cast: " + a.Actors + "\n"
                    + "Lingua originale: " + a.Language + "\n"
                    + "Paese di produzione: " + a.Country + "\n"
                    + "Premi: " + a.Awards + "\n"
                    + "Punteggio Metascore: " + a.Metascore + "\n"
                    + "Punteggio imdb: " + a.imdbRating + "\n"
                    + "Botteghino: " + a.BoxOffice + "\n";
                    pictureBoxPoster.LoadAsync(a.Poster);
            }
            else
                MessageBox.Show("Errore");
        }
    }
}