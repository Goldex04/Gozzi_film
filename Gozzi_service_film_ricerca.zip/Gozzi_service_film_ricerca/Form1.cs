﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Text.Json.Serialization;
using System.Windows.Forms;
namespace Gozzi_service_film_ricerca{
    public partial class Form1: Form{
        public class Film
        {
            public string Title { get; set; }
            public string Year { get; set; }
            public string Rated { get; set; }
            public string Type { get; set; }
            public string Runtime { get; set; }
            public string Genre { get; set; }
            public string Plot { get; set; }
            public string Director { get; set; }
            public string Writer { get; set; }
            public string Actors { get; set; }
            public string Language { get; set; }
            public string Country { get; set; }
            public string Awards { get; set; }
            public string Metascore { get; set; }
            public string imdbRating { get; set; }
            public string BoxOffice { get; set; }
            public string Poster { get; set; }
        }
        [JsonNumberHandling(JsonNumberHandling.AllowReadingFromString)]
        public class FilmSearchContent{
            public List<Film> Search { get; set; }
            public int totalResults { get; set; }
            public string Response { get; set; }
        }
        public class Gozzi_service_film_ricerca{
            static HttpClient client = new HttpClient();
            public static void init(){
                client.BaseAddress = new Uri("https://www.omdbapi.com");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
            }
            public static async Task<List<Film>> GetAllFilm(string title){ 
                string title1 = title.Replace(" ", "+");
                HttpResponseMessage response = await client.GetAsync("/?apikey=63c6db0e&s=" + title1);
                string listaFilm = await response.Content.ReadAsStringAsync();
                try{
                    FilmSearchContent searchResult = JsonSerializer.Deserialize<FilmSearchContent>(listaFilm);
                    if (searchResult == null || searchResult.totalResults == 0) return new List<Film>();
                    return searchResult.Search;
                }
                catch (Exception ex){
                    return new List<Film>();
                }
            }
            public static async Task<Film> GetFilm(string title){
                string title1 = title.Replace(" ", "+");
                HttpResponseMessage response = await client.GetAsync("/?apikey=63c6db0e&t=" + title1);
                string film = await response.Content.ReadAsStringAsync();
                try{
                    return JsonSerializer.Deserialize<Film>(film);
                }
                catch (Exception){
                    return null;
                }
            }
        }
        public Form1(){
            InitializeComponent();
            Gozzi_service_film_ricerca.init();
        }
        private async void InitializeView(List<Film> films){
            comboBoxFilm.Items.Clear();
            for (int i = 0; i < films.Count; i++){
                Film film = films[i];
                comboBoxFilm.Items.Add(film.Title);
            }
            if (films.Count > 0){ 
                comboBoxFilm.SelectedIndex = 0;
                Film a = await Gozzi_service_film_ricerca.GetFilm(films[0].Title);
                if (a == null) return;
                richTextBoxInformazioni.Text = "Titolo del film: " + a.Title + "\n"
                     + "Anno di uscita: " + a.Year + "\n"
                     + "Limite d'età: " + a.Rated + "\n"
                     + "Tipo film: " + a.Type + "\n"
                     + "Genere: " + a.Genre + "\n"
                     + "Trama del film: " + a.Plot + "\n"
                     + "Durata del film: " + a.Runtime + "\n"
                     + "Regista: " + a.Director + "\n"
                     + "Sceneggiatori: " + a.Writer + "\n"
                     + "Cast: " + a.Actors + "\n"
                     + "Lingua originale: " + a.Language + "\n"
                     + "Paese di produzione: " + a.Country + "\n"
                     + "Premi: " + a.Awards + "\n"
                     + "Punteggio Metascore: " + a.Metascore + "\n"
                     + "Punteggio imdb: " + a.imdbRating + "\n"
                     + "Botteghino: " + a.BoxOffice + "\n";
            }
            else{
                MessageBox.Show("Nessun film trovato per chiave di ricerca data.");
                pictureBoxPoster.LoadAsync("https://eclipsys.ca/wp-content/uploads/2022/03/Error-404.png");
            }
        }
        private async void buttonCerca_Click(object sender, EventArgs e){
            string titolo = textBoxParola.Text.Replace(" ", "+");
            List<Film> filmList = await Gozzi_service_film_ricerca.GetAllFilm(titolo);
            InitializeView(filmList);
        }
        private async void comboBoxFilm_SelectedIndexChanged_1(object sender, EventArgs e){
            if (!comboBoxFilm.Focused) return;
            string titolo = (string)comboBoxFilm.SelectedItem;
            string scelta_completa = titolo.Replace(" ", "+");
            Film a = await Gozzi_service_film_ricerca.GetFilm(scelta_completa);
            if (a != null){
                    richTextBoxInformazioni.Text = "Titolo del film: " + a.Title + "\n"
                     + "Anno di uscita: " + a.Year + "\n"
                     + "Limite d'età: " + a.Rated + "\n"
                     + "Tipo film: " +a.Type + "\n"
                     + "Genere: " + a.Genre + "\n"
                     + "Trama del film: " + a.Plot + "\n"
                     + "Durata del film: " + a.Runtime + "\n"
                     + "Regista: " + a.Director + "\n"
                     + "Sceneggiatori: " + a.Writer + "\n"
                     + "Cast: " + a.Actors + "\n"
                     + "Lingua originale: " + a.Language + "\n"
                     + "Paese di produzione: " + a.Country + "\n"
                     + "Premi: " + a.Awards + "\n"
                     + "Punteggio Metascore: " + a.Metascore + "\n"
                     + "Punteggio imdb: " + a.imdbRating + "\n"
                     + "Botteghino: " + a.BoxOffice + "\n";
                pictureBoxPoster.LoadAsync(a.Poster);
            }
            else
                MessageBox.Show("Errore");
        }
    }
}